export const config = /*json-start*/{
  "mainAssemblyName": "Mute.web.dll",
  "resources": {
    "hash": "sha256-lxTdVyNTv6MtwpmcFC/dw+TQgULfqrGlZGmR7YZiBYc=",
    "jsModuleNative": [
      {
        "name": "dotnet.native.js"
      }
    ],
    "jsModuleRuntime": [
      {
        "name": "dotnet.runtime.js"
      }
    ],
    "wasmNative": [
      {
        "name": "dotnet.native.wasm",
        "hash": "sha256-tiwdZMucQzlLcRIHWMv73WFLfCJfhyqmkDFCVz7TK9g="
      }
    ],
    "icu": [
      {
        "virtualPath": "icudt_CJK.dat",
        "name": "icudt_CJK.dat",
        "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk="
      },
      {
        "virtualPath": "icudt_EFIGS.dat",
        "name": "icudt_EFIGS.dat",
        "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc="
      },
      {
        "virtualPath": "icudt_no_CJK.dat",
        "name": "icudt_no_CJK.dat",
        "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs="
      }
    ],
    "coreAssembly": [
      {
        "virtualPath": "System.Private.CoreLib.wasm",
        "name": "System.Private.CoreLib.wasm",
        "hash": "sha256-J93u/BAsdNTEoAqUfXtzq6yRGjLJA255C5pfbjuVCMI="
      },
      {
        "virtualPath": "System.Runtime.InteropServices.JavaScript.wasm",
        "name": "System.Runtime.InteropServices.JavaScript.wasm",
        "hash": "sha256-fcPwQjhQFW5pzkAa1hwrjpruAh3mtsvUCiUF/Fy0GAA="
      }
    ],
    "assembly": [
      {
        "virtualPath": "GodotSharp.wasm",
        "name": "GodotSharp.wasm",
        "hash": "sha256-nXEQbFSrdN25JLib1trgnk6+jaNWo/jbPPGUKI8E1kA="
      },
      {
        "virtualPath": "Microsoft.Win32.Primitives.wasm",
        "name": "Microsoft.Win32.Primitives.wasm",
        "hash": "sha256-LvIDf4g5SDIhCCRh1OsgcJnzgpaZAjusz5uZlHCCALI="
      },
      {
        "virtualPath": "Mute.wasm",
        "name": "Mute.wasm",
        "hash": "sha256-pg3l2C8AtDLHnXuNGzX4IQjdXRe2CwBGE4pycctQWWE="
      },
      {
        "virtualPath": "Mute.web.wasm",
        "name": "Mute.web.wasm",
        "hash": "sha256-L6QsVJ9/mX0jLo5JRYPxlyqY6PIpC3sAIw2qTT+4+s4="
      },
      {
        "virtualPath": "System.Collections.Concurrent.wasm",
        "name": "System.Collections.Concurrent.wasm",
        "hash": "sha256-cg1Zm4NZYdzKYks86+g4Swp9KL7FU6Sbvl1174iRQNA="
      },
      {
        "virtualPath": "System.Collections.wasm",
        "name": "System.Collections.wasm",
        "hash": "sha256-k6j4G31zRB/VN86xgiC6u/x7t//PMBMRUsrkDgegawg="
      },
      {
        "virtualPath": "System.Collections.Immutable.wasm",
        "name": "System.Collections.Immutable.wasm",
        "hash": "sha256-RbtZMIk97xYJj6HZJiA08XBzlDRs8p1PA0zT49u7G58="
      },
      {
        "virtualPath": "System.Console.wasm",
        "name": "System.Console.wasm",
        "hash": "sha256-adrQtXlu00QMnKmhBDxslcaUXQhp3jY8SxMalmwBIx8="
      },
      {
        "virtualPath": "System.Diagnostics.StackTrace.wasm",
        "name": "System.Diagnostics.StackTrace.wasm",
        "hash": "sha256-SuxRiM1WJ81+o93hSUHoe03aU1zHO+pkNZdmCtNDo6A="
      },
      {
        "virtualPath": "System.Diagnostics.TraceSource.wasm",
        "name": "System.Diagnostics.TraceSource.wasm",
        "hash": "sha256-phOzk8XGIby1lirrFfLALw3OOe3OOgsAvr+8U4JZMow="
      },
      {
        "virtualPath": "System.IO.Compression.wasm",
        "name": "System.IO.Compression.wasm",
        "hash": "sha256-A3j/1dPOmY0x5PbG1UVCeIWMH08HoDn1tO/Ldudm9uQ="
      },
      {
        "virtualPath": "System.IO.Pipelines.wasm",
        "name": "System.IO.Pipelines.wasm",
        "hash": "sha256-P3efMSOfVCOb4KRJxC8w5mdhwshNltAbNhD4m3E4ekU="
      },
      {
        "virtualPath": "System.Linq.wasm",
        "name": "System.Linq.wasm",
        "hash": "sha256-pYhf5gEMSeSEAuluFnW0s60ZPchZTKKSUXuGf7d1dZo="
      },
      {
        "virtualPath": "System.Memory.wasm",
        "name": "System.Memory.wasm",
        "hash": "sha256-qcqPP40e+Dm6O10AjSBxZod9oWjWBFC+f09EH42u/9M="
      },
      {
        "virtualPath": "System.Private.Uri.wasm",
        "name": "System.Private.Uri.wasm",
        "hash": "sha256-Fu5GhqUo8CSkmUVPsgFCdEmh3dSgmDaQ5SaLpADOKbk="
      },
      {
        "virtualPath": "System.Runtime.wasm",
        "name": "System.Runtime.wasm",
        "hash": "sha256-wj63MKDYsWXqVtd8kRdiyR/fcDW9M9QA7eLQGFFL5mc="
      },
      {
        "virtualPath": "System.Runtime.InteropServices.wasm",
        "name": "System.Runtime.InteropServices.wasm",
        "hash": "sha256-T/809t9wPUfxuf7r1qrLP2goJkFYfceMU81BCkWRtIQ="
      },
      {
        "virtualPath": "System.Runtime.Loader.wasm",
        "name": "System.Runtime.Loader.wasm",
        "hash": "sha256-Bx7ecK+rU+lpwOllXH1xC5uwwmYF6GhpAZG37R/LPXQ="
      },
      {
        "virtualPath": "System.Runtime.Numerics.wasm",
        "name": "System.Runtime.Numerics.wasm",
        "hash": "sha256-vbghRDSgTQu8PYaAzzo6KInP93uazJ+XwojQAd0RScA="
      },
      {
        "virtualPath": "System.Security.Cryptography.wasm",
        "name": "System.Security.Cryptography.wasm",
        "hash": "sha256-00bQimLf6MeaT4JjECgdw9oTGg8n9twvOdBkenzJcgE="
      },
      {
        "virtualPath": "System.Text.Encoding.Extensions.wasm",
        "name": "System.Text.Encoding.Extensions.wasm",
        "hash": "sha256-uF51o2akkBfYdRZfqe4FJkun9DPGti9FT4qulezA4vU="
      },
      {
        "virtualPath": "System.Text.Encodings.Web.wasm",
        "name": "System.Text.Encodings.Web.wasm",
        "hash": "sha256-2sW9o6myHg5AjmDlYISIcQBAn1FlnQbCRhGxgm2IHkg="
      },
      {
        "virtualPath": "System.Text.Json.wasm",
        "name": "System.Text.Json.wasm",
        "hash": "sha256-B8VVNY9R4hJ8sYkaJI6nLuIGlqB7vRD0aq8oWYGBV4U="
      },
      {
        "virtualPath": "System.Text.RegularExpressions.wasm",
        "name": "System.Text.RegularExpressions.wasm",
        "hash": "sha256-J2cD9LoCYYbvRBpJQVwOFHuQaY+Om/0Ze1v3JNaeBjA="
      },
      {
        "virtualPath": "System.Threading.wasm",
        "name": "System.Threading.wasm",
        "hash": "sha256-wpoytg45TU6q546rv+ywHVD+Mf2EXH6xwGhgV/3iEWQ="
      },
      {
        "virtualPath": "twodog.wasm",
        "name": "twodog.wasm",
        "hash": "sha256-6ClZ4vnJbWPvTp2DPMO6aEdCJnAMpmh342gd3q8WZ7s="
      }
    ]
  },
  "debugLevel": 0,
  "globalizationMode": "sharded",
  "runtimeConfig": {
    "runtimeOptions": {
      "configProperties": {
        "Microsoft.Extensions.DependencyInjection.VerifyOpenGenericServiceTrimmability": true,
        "System.ComponentModel.DefaultValueAttribute.IsSupported": false,
        "System.ComponentModel.Design.IDesignerHost.IsSupported": false,
        "System.ComponentModel.TypeConverter.EnableUnsafeBinaryFormatterInDesigntimeLicenseContextSerialization": false,
        "System.ComponentModel.TypeDescriptor.IsComObjectDescriptorSupported": false,
        "System.Data.DataSet.XmlSerializationIsSupported": false,
        "System.Diagnostics.Debugger.IsSupported": false,
        "System.Diagnostics.Metrics.Meter.IsSupported": false,
        "System.Diagnostics.Tracing.EventSource.IsSupported": false,
        "System.Globalization.Invariant": false,
        "System.TimeZoneInfo.Invariant": false,
        "System.Linq.Enumerable.IsSizeOptimized": true,
        "System.Net.Http.EnableActivityPropagation": false,
        "System.Net.Http.WasmEnableStreamingResponse": true,
        "System.Net.SocketsHttpHandler.Http3Support": false,
        "System.Reflection.Metadata.MetadataUpdater.IsSupported": false,
        "System.Resources.ResourceManager.AllowCustomResourceTypes": false,
        "System.Resources.UseSystemResourceKeys": true,
        "System.Runtime.CompilerServices.RuntimeFeature.IsDynamicCodeSupported": true,
        "System.Runtime.InteropServices.BuiltInComInterop.IsSupported": false,
        "System.Runtime.InteropServices.EnableConsumingManagedCodeFromNativeHosting": false,
        "System.Runtime.InteropServices.EnableCppCLIHostActivation": false,
        "System.Runtime.InteropServices.Marshalling.EnableGeneratedComInterfaceComImportInterop": false,
        "System.Runtime.Serialization.EnableUnsafeBinaryFormatterSerialization": false,
        "System.StartupHookProvider.IsSupported": false,
        "System.Text.Encoding.EnableUnsafeUTF7Encoding": false,
        "System.Text.Json.JsonSerializer.IsReflectionEnabledByDefault": false,
        "System.Threading.Thread.EnableAutoreleasePool": false
      }
    }
  }
}/*json-end*/;